

<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card card-primary">
        <div class="card-header bg-white">
            <h4><?php echo e($title); ?></h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e($settings ? route('update_mainsettings',['mainSetting'=>$settings]) : route('save_mainsettings')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="nav-align-top mb-4">

                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                      <a class="nav-link <?php if($loop->index == 0): ?> active <?php endif; ?>" id="nav-<?php echo e($key); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($key); ?>" role="tab" aria-controls="nav-<?php echo e($key); ?>" aria-selected="<?php if($loop->index == 0): ?><?php echo e('true'); ?><?php else: ?><?php echo e('false'); ?><?php endif; ?>"><?php echo e($lang); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <div style="border: 1px solid #cccccc" class="tab-content" id="myTabContent">
                    <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="tab-pane fade  <?php if($loop->index == 0): ?> show active <?php endif; ?>" id="nav-<?php echo e($key); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($key); ?>-tab">
                        <div class="form-group mt-3 col-md-12">
                            <label><?php echo e(transWord('Name')); ?> - <?php echo e($lang); ?></label>
                            <input type="text" name="<?php echo e($key); ?>[name]" value="<?php echo e($settings->name ?  $settings->translate($key)->name : ""); ?>" class="form-control" placeholder="<?php echo e(transWord('Name')); ?>" required>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="row mb-3 mt-3">
                    <div class="col-6">
                        <?php if($settings->logo): ?>
                            <img alt="" src="<?php echo e(asset($settings->logo)); ?>"  style="width:200px;display:block;background:#252b3b;padding: 10px;border-radius: 10px;">
                        <?php endif; ?>
                        <label for="logo"><?php echo e(transWord('Logo')); ?></label>
                        <input type="file" name="logo" id="logo" class="form-control" accept="image/*" >
                    </div>
                    <div class="col-6">
                        <?php if($settings->favicon): ?>
                        <img alt="" src="<?php echo e(asset($settings->favicon)); ?>"  style="width:200px;display:block;background:#252b3b;padding: 10px;border-radius: 10px;">
                        <?php endif; ?>
                        <label for="favicon"><?php echo e(transWord('Fav Icon')); ?></label>
                        <input type="file" name="favicon" id="favicon" class="form-control" accept="image/*" >
                    </div>
                </div>


                <div class="row mb-3 mt-3">
                    <div class="col-6">
                        <label for="email"><?php echo e(transWord('Email')); ?></label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo e($settings->email ? $settings->email : ""); ?>" required>
                    </div>
                    <div class="col-6">
                        <label for="mobile"><?php echo e(transWord('Mobile')); ?></label>
                        <input type="text" name="mobile" id="mobile" class="form-control" value="<?php echo e($settings->mobile ? $settings->mobile : ""); ?>" required>
                    </div>
                </div>

            </div>
                <div class="modal-footer">
                    <input type="submit" value="<?php echo e(transWord('Save')); ?>" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        var languages = [];

        <?php foreach(getLang() as $key => $val){ ?>
        languages.push('<?php echo $val; ?>');
        <?php } ?>

        var i = 0;
        for (i; i < languages.length; i++) {
            CKEDITOR.replace( 'content['+languages[i]+']', {
                height: 300,
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\MainSettings\Providers\..\Resources\views/index.blade.php ENDPATH**/ ?>