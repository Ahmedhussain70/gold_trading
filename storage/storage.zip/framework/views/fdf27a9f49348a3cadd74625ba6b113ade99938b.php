
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        .modal-dialog-scrollable {
            height: auto !important;
        }
        /* ألوان التبويبات */
        .nav-tabs .nav-link {
            background-color: #f8f9fa; /* اللون الافتراضي */
            border: 1px solid #dee2e6; /* حدود */
            color: #495057; /* لون النص */
            transition: background-color 0.3s ease;
        }

        .nav-tabs .nav-link.active {
            background-color: #007bff; /* لون خاص للتبويب النشط */
            color: #fff; /* لون النص */
            border-color: #007bff; /* حدود */
        }

        /* ألوان إضافية لكل تبويب */
        #live-tab {
            background-color: #28a745; /* لون خاص لتبويب live */
            color: #fff;
        }

        #live-tab.active {
            background-color: #218838; /* لون أغمق للتبويب النشط */
        }

        #demo-tab {
            background-color: #ffc107; /* لون خاص لتبويب demo */
            color: #fff;
        }

        #demo-tab.active {
            background-color: #e0a800; /* لون أغمق للتبويب النشط */
        }

        /* تحسين الحدود */
        .nav-tabs .nav-link {
            border-radius: 5px; /* زوايا مستديرة */
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-white d-flex align-items-center justify-content-between border-bottom">
                    <strong class="card-title"><?php echo e($title); ?></strong>
                </div>
                <div class="card-body">
                    <!-- Tabs Navigation -->
                    <ul class="nav nav-tabs" id="transactionTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="live-tab" data-bs-toggle="tab" href="#live" role="tab"
                                aria-controls="live" aria-selected="true"><?php echo e(transWord('Live Transactions')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="demo-tab" data-bs-toggle="tab" href="#demo" role="tab"
                                aria-controls="demo" aria-selected="false"><?php echo e(transWord('Demo Transactions')); ?></a>
                        </li>
                    </ul>

                    <!-- Tabs Content -->
                    <div class="tab-content pt-3" id="transactionTabsContent">
                        <!-- Live Transactions Tab -->
                        <div class="tab-pane fade show active" id="live" role="tabpanel" aria-labelledby="live-tab">
                            <div class="table-responsive">
                                <table id="live-transactions" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(transWord('User')); ?></th>
                                            <th><?php echo e(transWord('Amount')); ?></th>
                                            <th><?php echo e(transWord('Request At')); ?></th>
                                            <th><?php echo e(transWord('Actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $liveTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->user != null): ?>
                                                <tr class="row_<?php echo e($value->id); ?>">
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <?php echo e($value->user->name); ?>

                                                    </td>
                                                    <td><?php echo e($value->amount); ?></td>
                                                    <td><?php echo e($value->created_at); ?></td>
                                                    <td>
                                                        <?php if($value->is_approval == 0): ?>
                                                            <a onclick="return confirm('Are You Sure?')"
                                                                href="<?php echo e(route('approve_withdraw', ['id' => $value->id])); ?>"
                                                                class="btn btn-primary btn-sm"><?php echo e(transWord('Approve')); ?></a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Demo Transactions Tab -->
                        <div class="tab-pane fade" id="demo" role="tabpanel" aria-labelledby="demo-tab">
                            <div class="table-responsive">
                                <table id="demo-transactions" class="table table-bordered dt-responsive nowrap"
                                    style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>#</th>
                                            <th><?php echo e(transWord('User')); ?></th>
                                            <th><?php echo e(transWord('Amount')); ?></th>
                                            <th><?php echo e(transWord('Request At')); ?></th>
                                            <th><?php echo e(transWord('Actions')); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $demoTransactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value->user != null): ?>
                                                <tr class="row_<?php echo e($value->id); ?>">
                                                    <td><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <?php echo e($value->user->name); ?>

                                                    </td>
                                                    <td><?php echo e($value->amount); ?></td>
                                                    <td><?php echo e($value->created_at); ?></td>
                                                    <td>
                                                        <?php if($value->is_approval == 0): ?>
                                                            <a onclick="return confirm('Are You Sure?')"
                                                                href="<?php echo e(route('approve_withdraw', ['id' => $value->id])); ?>"
                                                                class="btn btn-primary btn-sm"><?php echo e(transWord('Approve')); ?></a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- end col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function () {
        // تهيئة الجداول
        let liveTable = $('#live-transactions').DataTable();
        let demoTable = null;

        // عند التبديل بين التبويبات
        $('a[data-bs-toggle="tab"]').on('shown.bs.tab', function (e) {
            let target = $(e.target).attr("href"); // الحصول على معرف التبويب المفتوح

            if (target === '#demo' && !demoTable) {
                // تهيئة جدول Demo فقط عند فتح التبويب لأول مرة
                demoTable = $('#demo-transactions').DataTable();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\Wallet\Providers\..\Resources\views/pendingWithdrawal.blade.php ENDPATH**/ ?>