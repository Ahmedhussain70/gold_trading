<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <div class="text-sm-right d-none d-sm-block">
                  &copy;
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                  <?php echo e($main_settings->name); ?> - <?php echo e(transWord('Made With ♥')); ?>

                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/components/footer.blade.php ENDPATH**/ ?>