

<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .modal-dialog-scrollable {
            height: auto !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-white d-flex align-items-center justify-content-between border-bottom">
                    <strong class="card-title"><?php echo e($title); ?></strong>
                </div>
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive pt-0">
                                <table id="example" class="table table-bordered dt-responsive nowrap"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(transWord('User')); ?></th>
                                        <th><?php echo e(transWord('Amount')); ?></th>
                                        <th><?php echo e(transWord('Message')); ?></th>
                                        <th><?php echo e(transWord('Is Approval')); ?></th>
                                        <th><?php echo e(transWord('Approve At')); ?></th>
                                        <th><?php echo e(transWord('Actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $usdts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $usdt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($usdt->user != null): ?>
                                            <tr  class="row_<?php echo e($usdt->id); ?>">
                                                <td><?php echo e($index + 1); ?></td>
                                                <td>
                                                    <?php echo e($usdt->user->name); ?>

                                                </td>
                                                <td><?php echo e($usdt->amount); ?></td>
                                                <td><?php echo e($usdt->message); ?></td>
                                                <td>
                                                    <?php if($usdt->is_approval == 1): ?>
                                                        <i class="fa fa-check"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-times"></i>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php echo e($usdt->approve_at); ?>

                                                </td>
                                                <td>
                                                    <?php if($usdt->is_approval == 0): ?>
                                                        <a onclick="return confirm('Are You Sure?')" href="<?php echo e(route('approve_usdts',['id'=>$usdt->id])); ?>" class="btn btn-primary btn-sm"><?php echo e(transWord('Approve')); ?></a>    
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->
                </div>
            </div>
        </div> <!-- end col -->



    </div>


   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\Wallet\Providers\..\Resources\views/usdts.blade.php ENDPATH**/ ?>