<?php if($errors->any()): ?>
<div class="card border-danger" style="padding: 20px;">
    <div class="body text-danger">
        <h4 class="card-title"><?php echo e(transWord('Please fix errors')); ?></h4>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="card-text"><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/components/errors.blade.php ENDPATH**/ ?>