

<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .modal-dialog-scrollable {
            height: auto !important;
        }

        #imagePreview{
            width: 100%;
            height: 100%;
            border-radius: 15px;
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-white d-flex align-items-center justify-content-between border-bottom">
                    <strong class="card-title"><?php echo e(transWord(' Pages')); ?></strong>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_pages')): ?>
                    <div style="text-align: end" class="add_btn">
                        <a id="newPageModal" class="btn btn-primary" href="javascript:void(0);" data-toggle="modal" data-target="#pageModal">
                            <i class="fas fa-plus"></i>
                            <?php echo e(transWord('Add New')); ?>

                        </a>
                    </div>
                    <?php endif; ?>

                </div>
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive pt-0">
                                <table id="example" class="table table-bordered dt-responsive nowrap"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(transWord('Image')); ?></th>
                                        <th><?php echo e(transWord('Title')); ?></th>
                                        <th><?php echo e(transWord('Content')); ?></th>
                                        <th><?php echo e(transWord('Status')); ?></th>
                                        <th><?php echo e(transWord('Actions')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr  class="Row_<?php echo e($page->id); ?>">
                                            <td><?php echo e($index + 1); ?></td>
                                            <td>
                                                <?php if($page->image): ?>
                                                    <a href="<?php echo e(asset($page->image)); ?>">
                                                        <img src="<?php echo e(asset($page->image)); ?>" style="height: 70px;width:100%;border-radius: 10px" alt="">
                                                    </a>
                                                <?php else: ?>

                                                <?php endif; ?>

                                            </td>
                                            <td><?php echo e($page->title); ?></td>
                                            <td>
                                                <?php echo Str::limit(strip_tags($page->content), 30, $end=".." ); ?>

                                            </td>


                                            <td>
                                                <?php if($page->publish == 1 ): ?>
                                                    <i class="fas fa-check text-success"></i>
                                                <?php else: ?>
                                                    <i class="fas fa-times text-danger"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <ul style="" class="dtr-details" >

                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_pages')): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('edit_pages',['p' => $page])); ?>"
                                                           class="btn btn-primary btn-sm">
                                                            <i class="mdi mdi-pencil font-size-14"></i>
                                                        </a>
                                                    </li>
                                                    <?php endif; ?>

                                                    
                                                </ul>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->
                </div>
            </div>
        </div> <!-- end col -->



    </div>


    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_pages')): ?>
    <div class="modal fade" id="pageModal" tabindex="-1" role="dialog"
         aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg">
            <div class="modal-content ">
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="exampleModalScrollableTitle"><?php echo e(transWord('New Page')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body p-3">
                    <form action="<?php echo e(route('store_pages')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <div class="nav-align-top mb-4">

                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="nav-item">
                                        <a class="nav-link <?php if($loop->index == 0): ?> active <?php endif; ?>" id="nav-<?php echo e($key); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($key); ?>" role="tab" aria-controls="nav-<?php echo e($key); ?>" aria-selected="<?php if($loop->index == 0): ?><?php echo e('true'); ?><?php else: ?><?php echo e('false'); ?><?php endif; ?>"><?php echo e($lang); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div style="border: 1px solid #cccccc" class="tab-content" id="myTabContent">
                                <?php $__currentLoopData = config('app.languages'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="tab-pane fade  <?php if($loop->index == 0): ?> show active <?php endif; ?>" id="nav-<?php echo e($key); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($key); ?>-tab">
                                        <div class="form-group mt-3 col-md-12">
                                            <label><?php echo e(transWord('Name')); ?> - <?php echo e($lang); ?></label>
                                            <input  type="text" name="<?php echo e($key); ?>[title]" class="form-control" placeholder="<?php echo e(transWord('Name')); ?>" required>
                                        </div>

                                        <div class="form-group mt-3 col-md-12">
                                            <label for=""> <?php echo e(transWord('Content')); ?> - <?php echo e($lang); ?></label>
                                            <textarea  rows="6" name="<?php echo e($key); ?>[content]" class="form-control editor"></textarea>
                                        </div>


                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>


                        </div>




                        <div class="row">


                            <div class="col-md-8">
                                <div class="form-group mt-3">
                                    <label for="file" class=""> <?php echo e(transWord('Image')); ?></label>
                                    <div id="dropzone2">
                                        <div>Click Or Drag Here</div>
                                        <input name="image" type="file" id="imageUpload"/>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-4">
                                <a target="_blank" href="">
                                    <div id="imagePreview"></div>
                                </a>
                            </div>



                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label class="col-md-12 col-form-label">Status </label>
                                    <div class="col-md-12">
                                        <div class="mt-4 mt-lg-0">
                                            <select class="form-control" name="publish">
                                                <option value="1">
                                                    Show in website
                                                </option>
                                                <option value="0">
                                                    Hidden
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button id="closeBtn" type="button" class="btn btn-light waves-effect" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                            </div>
                        </div>
                    </form>
                </div>

            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <?php endif; ?>







<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $("#imagePreview").css(
                        "background-image",
                        "url(" + e.target.result + ")"
                    );
                    $("#imagePreview").hide();
                    $("#imagePreview").fadeIn(650);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#imageUpload").change(function () {
            readURL(this);
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\Pages\Providers\..\Resources\views/index.blade.php ENDPATH**/ ?>