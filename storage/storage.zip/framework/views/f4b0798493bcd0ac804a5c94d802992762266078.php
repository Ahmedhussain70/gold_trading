

<?php $__env->startSection('title',transWord('Sign In')); ?>

<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form id="formAuthentication" class="form-horizontal" action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group auth-form-group-custom mb-4">
        <i class="ri-user-2-line auti-custom-input-icon"></i>
        <label for="username"><?php echo e(transWord('Email address')); ?></label>
        <input type="text" class="form-control" name="email" id="username" placeholder="<?php echo e(transWord('Email address')); ?>" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group auth-form-group-custom mb-4">
        <i class="ri-lock-2-line auti-custom-input-icon"></i>
        <label for="userpassword"><?php echo e(transWord('Password')); ?></label>
        <input type="password" class="form-control" name="password" id="userpassword" placeholder="<?php echo e(transWord('Password')); ?>">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="custom-control custom-checkbox">
        <input type="checkbox" class="custom-control-input"
               id="customControlInline">
        <label class="custom-control-label" name="remember" for="customControlInline"> <?php echo e(transWord('Remember me')); ?></label>
    </div>
    
    <div class="mt-4 text-center">
    <button type="submit" class="btn btn-primary w-md waves-effect waves-light"><?php echo e(transWord('Login')); ?></button>
    
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/auth/login.blade.php ENDPATH**/ ?>