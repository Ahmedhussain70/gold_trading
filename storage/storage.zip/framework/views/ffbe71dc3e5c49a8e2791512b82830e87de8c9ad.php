<div class="row">
    <div class="col-12">
        <div class="page-title-box d-flex align-items-center justify-content-between">
            <h4 class="mb-0"><?php echo e(transWord('Dashboard')); ?></h4>

            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(transWord('Dashboard')); ?></a></li>
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ol>
            </div>

        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/components/breadcrumb.blade.php ENDPATH**/ ?>