

<?php $__env->startSection('title',transWord('All Users')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-header bg-white d-flex align-items-center justify-content-between border-bottom">
                <strong class="card-title"><?php echo e(transWord('Users')); ?></strong>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_users')): ?>
                <div style="text-align: end;" class="add_btn">
                    <a id="" class="btn btn-primary" href="<?php echo e(route('create_users')); ?>">
                        <i class="fas fa-plus"></i>
                        <?php echo e(transWord('Add New')); ?>

                    </a>
                </div>
                <?php endif; ?>

            </div>
            <div class="card-body">
                <div class="card-datatable table-responsive pt-0">
                    <table class="datatables-basic table table-bordered table-striped" id="example">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo e(transWord('Avatar')); ?></th>
                                <th><?php echo e(transWord('Name')); ?></th>
                                <th><?php echo e(transWord('Email Address')); ?></th>
                                <th><?php echo e(transWord('User Name')); ?></th>
                                <th><?php echo e(transWord('Mobile Number')); ?></th>
                                <th><?php echo e(transWord('Active Status')); ?></th>
                                <th><?php echo e(transWord('Roles')); ?></th>
                                <th><?php echo e(transWord('Is Verified')); ?></th>
                                <th><?php echo e(transWord('Actions')); ?></th>
                            </tr>
                        </thead>

                        <tbody id="permissionTable">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td>
                                    <?php if($user->avatar != null): ?>
                                        <img src="<?php echo e(asset($user->avatar)); ?>" width="40px;">
                                    <?php else: ?>
                                        <?php echo e(transWord('No Image')); ?>

                                    <?php endif; ?>    
                                </td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->username); ?></td>
                                <td><?php echo e($user->mobile_number); ?></td>
                                <td>
                                    <?php if($user->publish == 1): ?>
                                        <span class="badge bg-success"><?php echo e(transWord('Active')); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?php echo e(transWord('Not Active')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = getUserRole($user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-secondary"><?php echo e($item); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <?php if($user->is_verified == 1): ?>
                                        <span class="badge bg-success"><?php echo e(transWord('Verified')); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?php echo e(transWord('Not Verified')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td style="display: flex;justify-content: start;gap: 5px;">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_users')): ?>
                                        <a href="<?php echo e(route('show_users',['user'=>$user])); ?>" class="btn btn-primary btn-sm"><span><?php echo e(transWord('Details')); ?></span></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update_users')): ?>
                                        <a href="<?php echo e(route('edit_users',['user'=>$user])); ?>" class="btn btn-primary btn-sm"><span><?php echo e(transWord('Edit')); ?></span></a>
                                    <?php endif; ?>
                                    <?php if(!$user->hasRole('Admin')): ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete_users')): ?>
                                        <a href="<?php echo e(route('destroy_users',['user'=>$user])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are You Sure?')"><span><?php echo e(transWord('Delete')); ?></span></a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('verify_users')): ?>
                                            <?php if($user->is_verified == 1): ?>
                                                <a href="<?php echo e(route('verify_users',['user'=>$user,0])); ?>" class="btn btn-danger btn-sm"><span><?php echo e(transWord('Un Verify')); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('verify_users',['user'=>$user,1])); ?>" class="btn btn-primary btn-sm"><span><?php echo e(transWord('Verify')); ?></span></a>    
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('active_users')): ?>
                                            <?php if($user->publish == 1): ?>
                                                <a href="<?php echo e(route('active_users',['user'=>$user,0])); ?>" class="btn btn-danger btn-sm"><span><?php echo e(transWord('Disactive')); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('active_users',['user'=>$user,1])); ?>" class="btn btn-primary btn-sm"><span><?php echo e(transWord('Active')); ?></span></a>    
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\Accounts\Providers\..\Resources\views/Users/index.blade.php ENDPATH**/ ?>