

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="card card-primary">
        <div class="card-header">
            <h4><?php echo e($title); ?></h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('update_appsettings')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="form-group">
                    <label for="initial_demo_balance"><?php echo e(transWord('Initial Demo Balance')); ?></label>
                    <input type="number" name="initial_demo_balance" id="initial_demo_balance" class="form-control"
                        value="<?php echo e($settings['initial_demo_balance'] ?? 0); ?>" required>
                </div>

                <div class="form-group">
                    <label for="sell_commission_rate"><?php echo e(transWord('Sell Commission Rate (%)')); ?></label>
                    <input type="number" name="sell_commission_rate" id="sell_commission_rate" class="form-control"
                        value="<?php echo e($settings['sell_commission_rate'] ?? 0); ?>" step="0.01" required>
                </div>

                <div class="form-group">
                    <label for="minimum_withdraw"><?php echo e(transWord('Minimum Withdraw Amount')); ?></label>
                    <input type="number" name="minimum_withdraw" id="minimum_withdraw" class="form-control"
                        value="<?php echo e($settings['minimum_withdraw'] ?? 0); ?>" required>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(transWord('Save Settings')); ?></button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\AppSettings\Providers\..\Resources\views/index.blade.php ENDPATH**/ ?>