<div class="vertical-menu">

    <div data-simplebar class="h-100">
        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title"><?php echo e(transWord('Menu')); ?></li>
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Dashboard')); ?></span>
                    </a>
                </li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_roles')): ?>
                    <li>
                        <a href="<?php echo e(route('roles')); ?>" class="waves-effect">
                            <i class="ri-dashboard-line"></i>
                            <span><?php echo e(transWord('Roles')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_permissions')): ?>
                    <li>
                        <a href="<?php echo e(route('permissions')); ?>" class="waves-effect">
                            <i class="ri-dashboard-line"></i>
                            <span><?php echo e(transWord('Permissions')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>


                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_users')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="ri-store-2-line"></i>
                            <span><?php echo e(transWord('Users')); ?></span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_users')): ?>
                                <li><a href="<?php echo e(route('create_users')); ?>"><?php echo e(transWord('New User')); ?></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('users')); ?>"><?php echo e(transWord('Users')); ?></a></li>
                            <li><a href="<?php echo e(route('show_wallets')); ?>"><?php echo e(transWord('Wallets')); ?></a></li>
                            <li><a href="<?php echo e(route('pending_deposit')); ?>"><?php echo e(transWord('Pending Deposit')); ?></a></li>
                            <li><a href="<?php echo e(route('approved_deposit')); ?>"><?php echo e(transWord('Approved Deposit')); ?></a></li>
                            <li><a href="<?php echo e(route('pending_withdrawal')); ?>"><?php echo e(transWord('Pending Withdrawal')); ?></a></li>
                            <li><a href="<?php echo e(route('approved_withdrawal')); ?>"><?php echo e(transWord('Approved Withdrawal')); ?></a></li>
                            <li><a href="<?php echo e(route('show_usdts')); ?>"><?php echo e(transWord('USDT')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_sliders')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="fa fa-image"></i>
                            <span><?php echo e(transWord('Sliders')); ?></span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_sliders')): ?>
                                <li><a href="<?php echo e(route('create_slider_banners')); ?>"><?php echo e(transWord('New Slider')); ?></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('slider_banners')); ?>"><?php echo e(transWord('Sliders')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_pages')): ?>
                <li>
                    <a href="<?php echo e(route('show_pages')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Pages')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_blogs')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="fa fa-file"></i>
                            <span><?php echo e(transWord('Blogs')); ?></span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_blogs')): ?>
                                <li><a href="<?php echo e(route('create_blogs')); ?>"><?php echo e(transWord('New Blog')); ?></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('blogs')); ?>"><?php echo e(transWord('Blogs')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_faqs')): ?>
                <li>
                    <a href="<?php echo e(route('show_faq_settings')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('FAQs')); ?></span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_product_category')): ?>
                <li>
                    <a href="<?php echo e(route('show_product_category')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Product Category')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_product')): ?>
                <li>
                    <a href="<?php echo e(route('show_product')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Products')); ?></span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_orders')): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="ri-store-2-line"></i>
                            <span><?php echo e(transWord('Orders')); ?></span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create_orders')): ?>
                                <li><a href="<?php echo e(route('create_orders')); ?>"><?php echo e(transWord('New Order')); ?></a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route('show_orders')); ?>"><?php echo e(transWord('Orders')); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>



    
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_tickets')): ?>
                <li>
                    <a href="<?php echo e(route('show_tickets')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Tickets')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_homepage_social_media')): ?>
                <li>
                    <a href="<?php echo e(route('show_social_settings')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Social Media')); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_settings')): ?>
                <li>
                    <a href="<?php echo e(route('mainsettings')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Main Settings')); ?></span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('show_settings')): ?>
                <li>
                    <a href="<?php echo e(route('appsettings')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('App Settings')); ?></span>
                    </a>
                </li>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('language_settings')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Languages')); ?></span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('clear_cache')); ?>" class="waves-effect">
                        <i class="ri-dashboard-line"></i>
                        <span><?php echo e(transWord('Clear Cache')); ?></span>
                    </a>
                </li>

            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/components/menu.blade.php ENDPATH**/ ?>