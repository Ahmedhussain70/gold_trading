

<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .modal-dialog-scrollable {
            height: auto !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="breadcrumb-item active" aria-current="page">
            <a href="<?php echo e($page[1]); ?>"><?php echo e($page[0]); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('dashboard.components.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-white d-flex align-items-center justify-content-between border-bottom">
                    <strong class="card-title"><?php echo e($title); ?></strong>
                </div>
                <div class="card-body">

                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive pt-0">
                                <table id="example" class="table table-bordered dt-responsive nowrap"
                                       style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead class="thead-light">
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(transWord('user_id')); ?></th>
                                        <th><?php echo e(transWord('low_price')); ?></th>
                                        <th><?php echo e(transWord('high_price')); ?></th>
                                        <th><?php echo e(transWord('metal')); ?></th>
                                        <th><?php echo e(transWord('currency')); ?></th>
                                        <th><?php echo e(transWord('prev_close_price')); ?></th>
                                        <th><?php echo e(transWord('price')); ?></th>
                                        <th><?php echo e(transWord('ch')); ?></th>
                                        <th><?php echo e(transWord('chp')); ?></th>
                                        <th><?php echo e(transWord('ask')); ?></th>
                                        <th><?php echo e(transWord('bid')); ?></th>
                                        <th><?php echo e(transWord('price_gram_24k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_22k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_21k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_20k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_18k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_16k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_14k')); ?></th>
                                        <th><?php echo e(transWord('price_gram_10k')); ?></th>
                                        <th><?php echo e(transWord('open_price')); ?></th>
                                        <th><?php echo e(transWord('qty')); ?></th>
                                        <th><?php echo e(transWord('open_time')); ?></th>
                                        <th><?php echo e(transWord('stop_loss')); ?></th>
                                        <th><?php echo e(transWord('sell_when_price')); ?></th>
                                        <th><?php echo e(transWord('take_profit')); ?></th>
                                        <th><?php echo e(transWord('Type')); ?></th>
                                        <th><?php echo e(transWord('Address')); ?></th>
                                        <th><?php echo e(transWord('created_at')); ?></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr  class="row_<?php echo e($order->id); ?>">
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($order->user->name ?? ''); ?></td>
                                            <td><?php echo e($order->low_price); ?></td>
                                            <td><?php echo e($order->high_price); ?></td>
                                            <td><?php echo e($order->metal); ?></td>
                                            <td><?php echo e($order->currency); ?></td>
                                            <td><?php echo e($order->prev_close_price); ?></td>
                                            <td><?php echo e($order->price); ?></td>
                                            <td><?php echo e($order->ch); ?></td>
                                            <td><?php echo e($order->chp); ?></td>
                                            <td><?php echo e($order->ask); ?></td>
                                            <td><?php echo e($order->bid); ?></td>
                                            <td><?php echo e($order->price_gram_24k); ?></td>
                                            <td><?php echo e($order->price_gram_22k); ?></td>
                                            <td><?php echo e($order->price_gram_21k); ?></td>
                                            <td><?php echo e($order->price_gram_20k); ?></td>
                                            <td><?php echo e($order->price_gram_18k); ?></td>
                                            <td><?php echo e($order->price_gram_16k); ?></td>
                                            <td><?php echo e($order->price_gram_14k); ?></td>
                                            <td><?php echo e($order->price_gram_10k); ?></td>
                                            <td><?php echo e($order->open_price); ?></td>
                                            <td><?php echo e($order->qty); ?></td>
                                            <td><?php echo e($order->open_time); ?></td>
                                            <td><?php echo e($order->stop_loss); ?></td>
                                            <td><?php echo e($order->sell_when_price); ?></td>
                                            <td><?php echo e($order->take_profit); ?></td>
                                            <td><?php echo e($order->type); ?></td>
                                            <td><?php echo e($order->address); ?></td>
                                            <td><?php echo e($order->created_at); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div> <!-- end col -->
                    </div> <!-- end row -->
                </div>
            </div>
        </div> <!-- end col -->



    </div>


   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\app\Modules\Orders\Providers\..\Resources\views/index.blade.php ENDPATH**/ ?>