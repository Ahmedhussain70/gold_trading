<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php echo $__env->make('dashboard.components.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<body class="auth-body-bg">
  <div>
    <div class="container-fluid p-0">
        <div class="row no-gutters">
            <div class="col-lg-4">
                <div class="authentication-page-content p-4 d-flex align-items-center min-vh-100">
                    <div class="w-100">
                        <div class="row justify-content-center">
                            <div class="col-lg-9">
                                <div>
                                    <div class="text-center">
                                        <div>
                                            <a href="<?php echo e(route('dashboard')); ?>" class="logo"><img src="<?php echo e(asset($main_settings->logo)); ?>" style="background: #252b3b; border-radius: 10px; padding: 10px;" height="80" alt="logo"></a>
                                        </div>

                                        <h4 class="font-size-14 mt-4"><?php echo e(transWord('Welcome To ').$main_settings->name); ?></h4>
                                    </div>

                                    <div class="p-2 mt-5">
                                      <?php echo $__env->yieldContent('content'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
              <div class="authentication-bg">
                  <div class="bg-overlay"></div>
              </div>
          </div>
        </div>
    </div>
  </div>



    <?php echo $__env->make('dashboard.components.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/layouts/auth.blade.php ENDPATH**/ ?>