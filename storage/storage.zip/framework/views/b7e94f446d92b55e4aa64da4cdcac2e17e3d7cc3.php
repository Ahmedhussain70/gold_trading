

<?php $__env->startSection('title',transWord('Dashboard')); ?>

<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->hasRole('Admin')): ?>
<h4 class="mb-3"><?php echo e(transWord('Statistics')); ?></h4>
    <div class="row">
        <?php $__currentLoopData = $statistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card static">
                <div class="card-body">
                    <div class="media align-items-center text-center">
                        <div class="media-body overflow-hidden">
                            <p class="font-size-14 mb-2"><?php echo e($state[0]); ?></p>
                            <b class="text-primary font-size-20">
                                <?php echo e($state[1]); ?>

                            </b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
<?php endif; ?>
<h2 id="gold-price">السعر الحالي: غير متاح</h2>
<?php if(auth()->user()->hasRole('Vendor')): ?>
<?php
    $vendor = \Vendors\Models\Vendor::where('user_id',auth()->user()->id)->first();
?>
<h4 class="mb-3"><?php echo e(transWord('Statistics')); ?></h4>
    <div class="row">

        <?php $__currentLoopData = vendorStatistics($vendor->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card static">
                <div class="card-body">
                    <div class="media align-items-center text-center">
                        <div class="media-body overflow-hidden">
                            <p class="font-size-14 mb-2"><?php echo e($state[0]); ?></p>
                            <b class="text-primary font-size-20">
                                <?php echo e($state[1]); ?>

                            </b>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>    
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/6.0.2/firebase.js"></script>
<script>
    const firebaseConfig = {
        apiKey: "AIzaSyBRyMNqn7HcivokRvq_x4d41aQVfkKQYr8",
        authDomain: "elite-homes-9c47c.firebaseapp.com",
        projectId: "elite-homes-9c47c",
        storageBucket: "elite-homes-9c47c.appspot.com",
        messagingSenderId: "527981052710",
        appId: "1:527981052710:web:c731b965c8f56f022bf7e7",
        measurementId: "G-2GJQKJKKCH"
    };

    firebase.initializeApp(firebaseConfig);

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\officialgoldapp\resources\views/dashboard/index.blade.php ENDPATH**/ ?>